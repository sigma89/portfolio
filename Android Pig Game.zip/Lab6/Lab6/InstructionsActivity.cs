﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Lab5
{
	[Activity (Label = "InstructionsActivity", MainLauncher = true, Icon = "@mipmap/icon")]			
	public class InstructionsActivity : Activity
	{
		Pig pig;
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);

			SetContentView (Resource.Layout.Main);

			var instructionsTextView = FindViewById<TextView> (Resource.Id.instructionsTextView);
			var player1NameLabelTextView = FindViewById<TextView> (Resource.Id.player1NameLabelTextView);
			var playerNameLabelTextView = FindViewById<TextView> (Resource.Id.player2NameLabelTextView);
			var player1EditText = FindViewById<EditText> (Resource.Id.player1EditText);
			var player2EditText = FindViewById<EditText> (Resource.Id.player2EditText);
			var startButton = FindViewById<Button> (Resource.Id.startButton);

			bool isDualPane = false;
			var rollButton = FindViewById<Button> (Resource.Id.rollButton);
			if (rollButton != null)
			{
				//create game controller
				pig = new Pig();
				const string S_TURN = "'s turn";
				//get layout elements
				var player1TextView = FindViewById<TextView> (Resource.Id.player1TextView);
				player1TextView.Text = pig.player1Name = "Player 1";
				var player2TextView = FindViewById<TextView> (Resource.Id.player2TextView);
				player2TextView.Text = pig.player2Name = "Player 2";
				var player1ScoreTextView = FindViewById<TextView> (Resource.Id.player1ScoreTextView);
				var player2ScoreTextView = FindViewById<TextView> (Resource.Id.player2ScoreTextView);
				var turnTextView = FindViewById<TextView> (Resource.Id.turnTextView);
				turnTextView.Text = pig.player1Name + S_TURN;
				var diceImageView = FindViewById<ImageView> (Resource.Id.diceImageView);
				var pointsTextView = FindViewById<TextView> (Resource.Id.pointsTextView);

				var endButton = FindViewById<Button> (Resource.Id.endButton);
				var newGameButton = FindViewById<Button> (Resource.Id.newGameButton);

				//roll dice
				rollButton.Click += delegate {
					//change die image
					switch(pig.Roll()) {
					case 1:
						diceImageView.SetImageResource(Resource.Drawable.Die1);
						rollButton.Enabled = false;
						break;
					case 2:
						diceImageView.SetImageResource(Resource.Drawable.Die2);
						break;
					case 3:
						diceImageView.SetImageResource(Resource.Drawable.Die3);
						break;
					case 4:
						diceImageView.SetImageResource(Resource.Drawable.Die4);
						break;
					case 5:
						diceImageView.SetImageResource(Resource.Drawable.Die5);
						break;
					case 6:
						diceImageView.SetImageResource(Resource.Drawable.Die6);
						break;
					}

					//getpoints
					pointsTextView.Text = pig.pointsThisTurn.ToString();

				};

				endButton.Click += delegate {

					pig.EndTurn();

					//update text views
					player1ScoreTextView.Text = pig.player1Score.ToString();
					player2ScoreTextView.Text = pig.player2Score.ToString();
					pointsTextView.Text = pig.pointsThisTurn.ToString();

					//check if anyone has 100 points or over
					switch (pig.WinCheck()){
					case 0:
						rollButton.Enabled = true;
						if (pig.player1Turn)
							turnTextView.Text = pig.player1Name + S_TURN;
						else
							turnTextView.Text = pig.player2Name + S_TURN;
						break;
					case 1:
						//if next turn would be player one's, it's a new round, so player one wins
						if (pig.player1Turn)
						{
							turnTextView.Text = pig.player1Name + " WINS!";
							rollButton.Enabled = false;
							endButton.Enabled = false;
						}
						break;
					case 2:
						rollButton.Enabled = false;
						endButton.Enabled = false;
						turnTextView.Text = pig.player2Name + " WINS!";
						break;
					}
				};

				newGameButton.Click += delegate {
					pig.Reset();

					player1ScoreTextView.Text = pig.player1Score.ToString();
					player2ScoreTextView.Text = pig.player2Score.ToString();
					pointsTextView.Text = pig.pointsThisTurn.ToString();
					turnTextView.Text = pig.player1Name + S_TURN;

					rollButton.Enabled = true;
					endButton.Enabled = true;
				};

				startButton.Click += delegate {
					pig.player1Name = player1EditText.Text;
					pig.player2Name = player2EditText.Text;
					player1ScoreTextView.Text = pig.player1Score.ToString();
					player2ScoreTextView.Text = pig.player2Score.ToString();
					player1TextView.Text = pig.player1Name;
					player2TextView.Text = pig.player2Name;
					turnTextView.Text = pig.player1Name + S_TURN;

					
				};

				isDualPane = true;
			}



			startButton.Click += delegate {

				//launch game activity and pass player names
				var second = new Intent(this, typeof(MainActivity));

				if(!isDualPane)
				{
				//if anything was entered into edit texts, send to other activity
				if (player1EditText.Text != "")
				second.PutExtra("player1Name", player1EditText.Text);
				if (player2EditText.Text != "")
				second.PutExtra("player2Name", player2EditText.Text);
				StartActivity(second);
				}
			};
		}
	}
}