﻿using System;

namespace Lab5
{
	public class Pig
	{
		public string player1Name {get; set;}
		public string player2Name { get; set;}
		public int player1Score { get; set;}
		public int player2Score { get; set;}
		public int pointsThisTurn {get; set;}
		public int die { get; set;}
		public bool player1Turn { get; set;}
		private Random random;
		private const int WIN_SCORE = 100;

		public Pig ()
		{
			player1Name = player2Name = "";
			pointsThisTurn = die = player2Score = player1Score = 0;
			random = new Random ();
			player1Turn = true;
		}

		public int Roll()
		{
			die = random.Next(1, 7);

			if (die == 1) {
				pointsThisTurn = 0;
			} else {
				pointsThisTurn += die;
			}

			return die;
		}

		public void EndTurn()
		{
			if (player1Turn)
				player1Score += pointsThisTurn;
			else
				player2Score += pointsThisTurn;


			player1Turn = !player1Turn;
			pointsThisTurn = 0;
		}

		public void Reset()
		{
			pointsThisTurn = die = player2Score = player1Score = 0;
			player1Turn = true;
		}

		public int WinCheck()
		{
			if (player1Score >= WIN_SCORE && player1Score > player2Score)
				return 1;
			else if (player2Score >= WIN_SCORE && player2Score > player1Score)
				return 2;
			else
				return 0;
		}
	}
}

