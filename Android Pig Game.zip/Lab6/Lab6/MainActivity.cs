﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace Lab5
{
	[Activity (Label = "Pig")]
	public class MainActivity : Activity
	{
		Pig pig;
		const string S_TURN = "'s turn";

		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);

			pig = new Pig();
			
			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Pig);

			//get layout elements
			var player1TextView = FindViewById<TextView> (Resource.Id.player1TextView);
			player1TextView.Text = pig.player1Name = Intent.GetStringExtra ("player1Name") ?? "Player 1";
			var player2TextView = FindViewById<TextView> (Resource.Id.player2TextView);
			player2TextView.Text = pig.player2Name = Intent.GetStringExtra ("player2Name") ?? "Player 2";
			var player1ScoreTextView = FindViewById<TextView> (Resource.Id.player1ScoreTextView);
			var player2ScoreTextView = FindViewById<TextView> (Resource.Id.player2ScoreTextView);
			var turnTextView = FindViewById<TextView> (Resource.Id.turnTextView);
			turnTextView.Text = pig.player1Name + S_TURN;
			var diceImageView = FindViewById<ImageView> (Resource.Id.diceImageView);
			var pointsTextView = FindViewById<TextView> (Resource.Id.pointsTextView);

			var rollButton = FindViewById<Button> (Resource.Id.rollButton);
			var endButton = FindViewById<Button> (Resource.Id.endButton);
			var newGameButton = FindViewById<Button> (Resource.Id.newGameButton);

			//roll dice
			rollButton.Click += delegate {
				//change die image
				switch(pig.Roll()) {
				case 1:
					diceImageView.SetImageResource(Resource.Drawable.Die1);
					rollButton.Enabled = false;
					break;
				case 2:
					diceImageView.SetImageResource(Resource.Drawable.Die2);
					break;
				case 3:
					diceImageView.SetImageResource(Resource.Drawable.Die3);
					break;
				case 4:
					diceImageView.SetImageResource(Resource.Drawable.Die4);
					break;
				case 5:
					diceImageView.SetImageResource(Resource.Drawable.Die5);
					break;
				case 6:
					diceImageView.SetImageResource(Resource.Drawable.Die6);
					break;
				}

				//getpoints
				pointsTextView.Text = pig.pointsThisTurn.ToString();

			};

			endButton.Click += delegate {
				
				pig.EndTurn();

				//update text views
				player1ScoreTextView.Text = pig.player1Score.ToString();
				player2ScoreTextView.Text = pig.player2Score.ToString();
				pointsTextView.Text = pig.pointsThisTurn.ToString();

				//check if anyone has 100 points or over
				switch (pig.WinCheck()){
				case 0:
					rollButton.Enabled = true;
					if (pig.player1Turn)
						turnTextView.Text = pig.player1Name + S_TURN;
					else
						turnTextView.Text = pig.player2Name + S_TURN;
					break;
				case 1:
					//if next turn would be player one's, it's a new round, so player one wins
					if (pig.player1Turn)
					{
						turnTextView.Text = pig.player1Name + " WINS!";
						rollButton.Enabled = false;
						endButton.Enabled = false;
					}
					break;
				case 2:
					rollButton.Enabled = false;
					endButton.Enabled = false;
					turnTextView.Text = pig.player2Name + " WINS!";
					break;
				}
			};

			newGameButton.Click += delegate {
				pig.Reset();

				player1ScoreTextView.Text = pig.player1Score.ToString();
				player2ScoreTextView.Text = pig.player2Score.ToString();
				pointsTextView.Text = pig.pointsThisTurn.ToString();
				turnTextView.Text = pig.player1Name + S_TURN;

				rollButton.Enabled = true;
				endButton.Enabled = true;
			};
		}
	}

}


